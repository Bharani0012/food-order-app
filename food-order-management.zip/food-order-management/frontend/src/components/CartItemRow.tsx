import type { CartItem } from "../types";
import { useCart } from "../context/CartContext";

export default function CartItemRow({ item }: { item: CartItem }) {
  const { increaseQuantity, decreaseQuantity, removeItem } = useCart();

  return (
    <div className="flex items-center justify-between border-b py-3">
      <div>
        <p className="font-medium">{item.name}</p>
        <p className="text-sm text-gray-500">₹{item.price} each</p>
      </div>
      <div className="flex items-center gap-3">
        <button
          onClick={() => decreaseQuantity(item.id)}
          className="px-2 py-1 border rounded"
        >
          -
        </button>
        <span>{item.quantity}</span>
        <button
          onClick={() => increaseQuantity(item.id)}
          className="px-2 py-1 border rounded"
        >
          +
        </button>
        <span className="w-20 text-right font-semibold">
          ₹{(item.price * item.quantity).toFixed(2)}
        </span>
        <button
          onClick={() => removeItem(item.id)}
          className="text-red-600 hover:underline"
        >
          Remove
        </button>
      </div>
    </div>
  );
}
