import type { MenuItem } from "../types";
import { useCart } from "../context/CartContext";

export default function MenuCard({ item }: { item: MenuItem }) {
  const { addItem } = useCart();

  return (
    <div className="border rounded-lg shadow-sm overflow-hidden flex flex-col bg-white">
      <img src={item.image_url ?? undefined} alt={item.name} className="w-full h-40 object-cover" />
      <div className="p-4 flex flex-col flex-1">
        <h3 className="font-semibold text-lg">{item.name}</h3>
        <p className="text-gray-500 text-sm flex-1">{item.description}</p>
        <div className="flex items-center justify-between mt-3">
          <span className="font-bold">₹{item.price}</span>
          <button
            onClick={() => addItem(item)}
            className="bg-orange-600 text-white px-3 py-1 rounded hover:bg-orange-700"
          >
            + Add
          </button>
        </div>
      </div>
    </div>
  );
}
