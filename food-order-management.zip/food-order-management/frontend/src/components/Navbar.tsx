import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";

export default function Navbar() {
  const { user, logout } = useAuth();
  const { totalCount } = useCart();
  const navigate = useNavigate();

  function handleLogout() {
    logout();
    navigate("/login");
  }

  return (
    <nav className="bg-orange-600 text-white px-4 py-3 flex items-center justify-between">
      <Link to="/menu" className="font-bold text-lg">
        Food Order
      </Link>
      <div className="flex items-center gap-4">
        <Link to="/menu" className="hover:underline">
          Menu
        </Link>
        <Link to="/cart" className="hover:underline relative">
          Cart
          {totalCount > 0 && (
            <span className="ml-1 bg-white text-orange-600 rounded-full px-2 py-0.5 text-xs font-semibold">
              {totalCount}
            </span>
          )}
        </Link>
        {user ? (
          <>
            <span className="text-sm">Hi, {user.username}</span>
            <button onClick={handleLogout} className="hover:underline">
              Logout
            </button>
          </>
        ) : (
          <>
            <Link to="/login" className="hover:underline">
              Login
            </Link>
            <Link to="/register" className="hover:underline">
              Register
            </Link>
          </>
        )}
      </div>
    </nav>
  );
}
