import type { OrderStatus } from "../types";

const STEPS: { key: OrderStatus; label: string }[] = [
  { key: "RECEIVED", label: "Order Received" },
  { key: "PREPARING", label: "Preparing" },
  { key: "OUT_FOR_DELIVERY", label: "Out for Delivery" },
  { key: "DELIVERED", label: "Delivered" },
];

export default function OrderStatusTracker({ status }: { status: OrderStatus }) {
  const currentIndex = STEPS.findIndex((step) => step.key === status);

  return (
    <ul className="space-y-2">
      {STEPS.map((step, index) => {
        const isDone = index < currentIndex;
        const isCurrent = index === currentIndex;
        return (
          <li
            key={step.key}
            className={`flex items-center gap-2 ${
              isDone || isCurrent ? "text-green-700 font-medium" : "text-gray-400"
            }`}
          >
            <span>{isDone ? "✓" : isCurrent ? "●" : "○"}</span>
            {step.label}
          </li>
        );
      })}
    </ul>
  );
}
