import { Link } from "react-router-dom";
import { useCart } from "../context/CartContext";
import CartItemRow from "../components/CartItemRow";

export default function Cart() {
  const { items, totalPrice } = useCart();

  if (items.length === 0) {
    return (
      <div className="p-6">
        <p>Your cart is empty.</p>
        <Link to="/menu" className="text-orange-600 hover:underline">
          Browse the menu
        </Link>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Your Cart</h1>
      {items.map((item) => (
        <CartItemRow key={item.id} item={item} />
      ))}
      <div className="flex justify-between items-center mt-4 text-lg font-bold">
        <span>Total</span>
        <span data-testid="cart-total">₹{totalPrice.toFixed(2)}</span>
      </div>
      <Link
        to="/checkout"
        className="mt-4 block text-center bg-orange-600 text-white rounded py-2 hover:bg-orange-700"
      >
        Proceed to Checkout
      </Link>
    </div>
  );
}
