import { useState, type FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { useCart } from "../context/CartContext";
import { createOrder } from "../services/orderService";

export default function Checkout() {
  const { items, totalPrice, clearCart } = useCart();
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    setError("");

    if (!/^\d{7,15}$/.test(phone)) {
      setError("Enter a valid phone number (digits only)");
      return;
    }

    setSubmitting(true);
    try {
      const order = await createOrder({
        delivery_name: name,
        delivery_address: address,
        delivery_phone: phone,
        items: items.map((item) => ({ menu_item_id: item.id, quantity: item.quantity })),
      });
      clearCart();
      navigate(`/orders/${order.id}`);
    } catch (err) {
      if (axios.isAxiosError(err) && err.response?.data?.detail) {
        setError(String(err.response.data.detail));
      } else {
        setError("Could not place order");
      }
    } finally {
      setSubmitting(false);
    }
  }

  if (items.length === 0) {
    return <p className="p-6">Your cart is empty. Add items before checking out.</p>;
  }

  return (
    <div className="p-6 max-w-md mx-auto">
      <h1 className="text-2xl font-bold mb-4">Checkout</h1>
      <p className="mb-4 font-medium">Order Total: ₹{totalPrice.toFixed(2)}</p>
      <form onSubmit={handleSubmit} className="flex flex-col gap-3">
        <input
          className="border rounded px-3 py-2"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <input
          className="border rounded px-3 py-2"
          placeholder="Address"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          required
        />
        <input
          className="border rounded px-3 py-2"
          placeholder="Phone Number"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          required
        />
        {error && <p className="text-red-600 text-sm">{error}</p>}
        <button
          disabled={submitting}
          className="bg-orange-600 text-white rounded py-2 hover:bg-orange-700 disabled:opacity-50"
        >
          {submitting ? "Placing order..." : "Place Order"}
        </button>
      </form>
    </div>
  );
}
