import { useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const { login } = useAuth();
  const navigate = useNavigate();

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    setError("");
    try {
      await login(username, password);
      navigate("/menu");
    } catch {
      setError("Invalid username or password");
    }
  }

  return (
    <div className="max-w-sm mx-auto mt-10 p-6 border rounded-lg shadow-sm">
      <h1 className="text-xl font-bold mb-4">Login</h1>
      <form onSubmit={handleSubmit} className="flex flex-col gap-3">
        <input
          className="border rounded px-3 py-2"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          required
        />
        <input
          className="border rounded px-3 py-2"
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        {error && <p className="text-red-600 text-sm">{error}</p>}
        <button className="bg-orange-600 text-white rounded py-2 hover:bg-orange-700">
          Login
        </button>
      </form>
      <p className="mt-4 text-sm">
        No account?{" "}
        <Link to="/register" className="text-orange-600 hover:underline">
          Register
        </Link>
      </p>
    </div>
  );
}
