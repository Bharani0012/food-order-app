import { useEffect, useState } from "react";
import { getMenuItems } from "../services/menuService";
import type { MenuItem } from "../types";
import MenuCard from "../components/MenuCard";

export default function Menu() {
  const [items, setItems] = useState<MenuItem[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    getMenuItems()
      .then(setItems)
      .catch(() => setError("Could not load menu"));
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Menu</h1>
      {error && <p className="text-red-600">{error}</p>}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map((item) => (
          <MenuCard key={item.id} item={item} />
        ))}
      </div>
    </div>
  );
}
