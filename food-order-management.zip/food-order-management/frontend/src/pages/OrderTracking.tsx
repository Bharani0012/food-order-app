import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getOrder, getOrderStatusSocketUrl } from "../services/orderService";
import type { Order, OrderStatus } from "../types";
import OrderStatusTracker from "../components/OrderStatusTracker";

export default function OrderTracking() {
  const { id } = useParams();
  const [order, setOrder] = useState<Order | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!id) return;
    getOrder(id)
      .then(setOrder)
      .catch(() => setError("Order not found"));
  }, [id]);

  // Live status updates: the backend simulates the kitchen progressing the order
  useEffect(() => {
    if (!id) return;
    const socket = new WebSocket(getOrderStatusSocketUrl(id));
    socket.onmessage = (event) => {
      const data = JSON.parse(event.data) as { status?: OrderStatus };
      if (data.status) {
        setOrder((prev) => (prev ? { ...prev, status: data.status as OrderStatus } : prev));
      }
    };
    return () => socket.close();
  }, [id]);

  if (error) return <p className="p-6 text-red-600">{error}</p>;
  if (!order) return <p className="p-6">Loading order...</p>;

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Order #{order.id}</h1>

      <div className="border rounded-lg p-4 mb-4">
        <OrderStatusTracker status={order.status} />
      </div>

      <div className="border rounded-lg p-4 mb-4">
        <h2 className="font-semibold mb-2">Delivery Details</h2>
        <p>{order.delivery_name}</p>
        <p>{order.delivery_address}</p>
        <p>{order.delivery_phone}</p>
      </div>

      <div className="border rounded-lg p-4">
        <h2 className="font-semibold mb-2">Items</h2>
        {order.items.map((item) => (
          <div key={item.id} className="flex justify-between py-1">
            <span>
              #{item.menu_item_id} x {item.quantity}
            </span>
            <span>₹{item.subtotal.toFixed(2)}</span>
          </div>
        ))}
        <div className="flex justify-between font-bold mt-2 border-t pt-2">
          <span>Total</span>
          <span>₹{order.total_amount.toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
}
